#pragma once



#include "file_template.hpp"
#include "string.hpp"



/***********************************************************************************************************************************
* libjimmy::types namespace
***********************************************************************************************************************************/
namespace libjimmy::types {


	
	typedef FileTemplate<String> StringFile;
	
	

}


